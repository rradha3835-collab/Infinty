package com.jeefocus.app

import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.app.Activity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var report: TextView
    private val limitMinutes = 120L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 16, 32)
        window.navigationBarColor = Color.rgb(11, 16, 32)
        buildUi()
        refreshUsage()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 36)
            setBackgroundColor(Color.rgb(11, 16, 32))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "JEE FOCUS"
            textSize = 13f
            letterSpacing = .16f
            setTextColor(Color.rgb(101, 224, 210))
        })
        root.addView(TextView(this).apply {
            text = "Phone usage"
            textSize = 30f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = "Today's app activity, so you can protect your study time."
            textSize = 15f
            setTextColor(Color.LTGRAY)
        })
        val grant = Button(this).apply {
            text = "Grant / open Usage Access settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        root.addView(grant)
        root.addView(Button(this).apply {
            text = "Refresh usage"
            setOnClickListener { refreshUsage() }
        })
        report = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, 24, 0, 20)
        }
        root.addView(report)
        root.addView(TextView(this).apply {
            text = "Privacy: this starter reads usage summaries only after you grant Android Usage Access. It does not read message contents, passwords, or what you type. Usage data is not uploaded anywhere."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 16, 0, 0)
        })
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun refreshUsage() {
        if (!hasUsageAccess()) {
            report.text = "Usage access is not enabled yet. Tap the button above, find JEE Focus, enable Usage Access, then return and tap Refresh usage."
            return
        }
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val start = calendar.timeInMillis
        val end = System.currentTimeMillis()
        val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats: List<UsageStats> = manager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY, start, end
        ).orEmpty()
        val merged = stats.groupBy { it.packageName }
            .mapValues { (_, entries) -> entries.sumOf { it.totalTimeInForeground } }
            .filterValues { it > 0 }
            .toList()
            .sortedByDescending { it.second }

        if (merged.isEmpty()) {
            report.text = "No usage data returned yet. Use a few apps, then refresh. Some Android phones take a little time to populate usage summaries."
            return
        }

        val pm = packageManager
        val lines = merged.mapNotNull { (pkg, millis) ->
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) { null }
            label?.let { it to millis / 60_000L }
        }.sortedByDescending { it.second }

        val socialPattern = Regex(
            "instagram|youtube|facebook|snapchat|reddit|tiktok|twitter|free fire|pubg|bgmi|game|gaming|discord|netflix",
            RegexOption.IGNORE_CASE
        )
        val social = lines.filter { socialPattern.containsMatchIn(it.first) }.sumOf { it.second }
        val total = lines.sumOf { it.second }
        val fmt = SimpleDateFormat("EEE, d MMM · h:mm a", Locale.getDefault())
        val out = StringBuilder()
        out.append("Updated ").append(fmt.format(Date())).append("\n\n")
        out.append("Total app foreground time: ").append(formatMinutes(total)).append("\n")
        out.append("Recognized social/video/gaming apps: ").append(formatMinutes(social)).append("\n")
        if (social > limitMinutes) {
            out.append("\n⚠️ SCREEN-TIME NUDGE\nYou've spent more than ")
                .append(formatMinutes(limitMinutes))
                .append(" in recognized social/video/gaming apps. Consider putting the phone away for one focused study sprint.\n")
        } else {
            out.append("\nYou're within the starter ")
                .append(formatMinutes(limitMinutes))
                .append(" social/video/gaming limit.\n")
        }
        out.append("\nAPP BREAKDOWN\n")
        lines.take(30).forEach { (label, minutes) ->
            out.append("• ").append(label).append(" — ").append(formatMinutes(minutes)).append("\n")
        }
        report.text = out.toString()
    }

    private fun formatMinutes(minutes: Long): String {
        val h = minutes / 60
        val m = minutes % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }
}
