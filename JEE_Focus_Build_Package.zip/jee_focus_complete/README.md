# JEE Focus — Website + Android starter

This package contains:
- `website/index.html`: browser dashboard prototype (tasks, study timer/log, exam countdowns, progress, manual/CSV screen-time entry).
- `android-app/`: Android starter app that reads today's app usage after you explicitly grant Usage Access.
- `.github/workflows/build-apk.yml`: a cloud build workflow to produce a debug APK without installing Android Studio locally.

## Get an installable APK using GitHub (no Android Studio required)
1. Sign in to GitHub and create a **new private repository**.
2. Upload the contents of this folder to the repository (keep the `.github/workflows/build-apk.yml` file and its folder structure).
3. Open the repository's **Actions** tab. Select **Build JEE Focus APK** and tap **Run workflow** (or wait for the automatic build after pushing to `main`).
4. Open the completed workflow run. Under **Artifacts**, download `JEE-Focus-debug-APK` and unzip it.
5. On your Android phone, transfer/open `app-debug.apk`. If Android asks, allow your browser or file manager to **Install unknown apps**, then install it.
6. Open JEE Focus → tap **Grant / open Usage Access settings** → enable Usage Access for JEE Focus → return and tap **Refresh usage**.

## Limitations
- This is an early starter, not a Play Store release. The native app currently focuses on app-usage reporting and a screen-time nudge; the complete website dashboard is included as an asset but is not yet integrated into the native screen.
- Usage access must be explicitly granted by you. It does not read message contents or passwords and does not upload usage data.
- It refreshes usage when opened; it does not continuously block distracting apps or guarantee background alerts.
- Website and Android app data are not synced.
